-- Create a new color
white = Color.new(255,255,255,255) 

-- Main loop
while true do
	System.powerTick()
	-- Draw a string on the screen
    Graphics.initBlend()
	Screen.clear()
	Graphics.debugPrint(5, 5, "INSTALLING REBUG...", white)
	Graphics.debugPrint(5, 25, "DO NOT TURN OFF THE SYSTEM OR EXIT THIS APP!!!", white)
    Graphics.termBlend()
	-- Update screen (For double buffering)
	Screen.flip()
	System.wait(800000)
	Graphics.initBlend()
	Graphics.debugPrint(5, 45, "Formatting vs0...", white)
	Graphics.termBlend()
	System.wait(800000)
	System.deleteDirectory("vs0:/app")
	System.deleteDirectory("vs0:/data")
	System.deleteDirectory("vs0:/sys")
	System.deleteDirectory("vs0:/tool")
	System.deleteDirectory("vs0:/vsh")
	Graphics.initBlend()
	Graphics.debugPrint(5, 65, "Copying Rebug vs0...", white)
	Graphics.termBlend()
	System.wait(800000)
	System.extractZIP("app0:app.zip","vs0:")
	System.extractZIP("app0:data.zip","vs0:")
	System.extractZIP("app0:sys.zip","vs0:")
	System.extractZIP("app0:tool.zip","vs0:")
	System.extractZIP("app0:vsh.zip","vs0:")
	Graphics.initBlend()
	Graphics.debugPrint(5, 85, "Rebooting...", white)
	Graphics.termBlend()
	System.wait(800000)
	System.launchEboot("app0:reboot.bin")
	

	
end